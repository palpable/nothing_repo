class HomeController < ApplicationController
  skip_before_filter :require_activation
  
  def index
    @body = "home"
    @topics = Topic.find_recent
    @members = Person.find_recent
    if logged_in?
      @feed = current_person.feed
      @some_contacts = current_person.some_contacts
      @requested_contacts = current_person.requested_contacts
      @forums = Forum.paginate(:page => params[:page_forums], :per_page => 15, :order => 'created_at DESC')
    else
	    redirect_to '/landing'
	    return
    end

    respond_to do |format|
      format.html
      format.atom
    end  
  end
end
