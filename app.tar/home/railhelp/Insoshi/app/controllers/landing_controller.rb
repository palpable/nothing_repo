class LandingController < ApplicationController

  def index
	  # This grabs the 5 most recently updated forum posts. 
	  @recent_disc = Topic.find(:all, :order => "updated_at DESC", :limit => 5, :select =>"id, name" )
	  # This shows the number of members currently registered for the site.
	  @members = Person.count(:all)	
	  
  end

end
