class Resources::BanksController < ApplicationController

  def index
  end

end
