class Country < ActiveRecord::Base
  has_many :people
end
