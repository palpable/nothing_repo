class Docattachment < ActiveRecord::Base
  belongs_to :attachable, :polymorphic => true
  has_attachment     :storage => :file_system,
                     :thumbnails => { :bigthumb => '400>', :thumb => '120>', :tiny => '50>' },
                     :path_prefix => 'public/uploads',
                     :max_size => 20.megabyte
end
