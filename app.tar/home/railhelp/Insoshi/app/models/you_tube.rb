class YouTube < ActiveResource::Base
  acts_as_youtube_model
end