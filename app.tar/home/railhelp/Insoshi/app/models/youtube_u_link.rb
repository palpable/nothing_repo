class YoutubeULink < ActiveRecord::Base
  belongs_to :road_show
end
